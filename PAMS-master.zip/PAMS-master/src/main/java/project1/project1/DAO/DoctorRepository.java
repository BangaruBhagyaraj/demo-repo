package project1.project1.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import project1.project1.model.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    Doctor findByEmailAndPassword(String email, String password);
}

