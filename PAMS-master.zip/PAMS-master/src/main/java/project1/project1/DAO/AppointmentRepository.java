package project1.project1.DAO;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import project1.project1.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByPatient_PatientId(Long patientId);
    List<Appointment> findByDoctor_DoctorId(Long doctorId);
	//List<Appointment> findByDoctor_DoctorIdAndAppointmentDate1(Long doctorId, LocalDate date);
	List<Appointment> findByDoctor_DoctorIdAndAppointmentDate(Long doctorId, LocalDate date);
}

