package project1.project1.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import project1.project1.DAO.NotificationRepository;
import project1.project1.model.Notification;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    public Notification sendConfirmationNotification(Long recipientId, String message) {
        Notification notification = new Notification();
        notification.setRecipientId(recipientId);
        notification.setMessage(message);
        notification.setNotificationType(Notification.NotificationType.CONFIRMATION);
        notification.setSentDate(LocalDateTime.now());
        return notificationRepository.save(notification);
    }

    public Notification sendAppointmentReminder(Long recipientId, String message) {
        Notification notification = new Notification();
        notification.setRecipientId(recipientId);
        notification.setMessage(message);
        notification.setNotificationType(Notification.NotificationType.REMINDER);
        notification.setSentDate(LocalDateTime.now());
        return notificationRepository.save(notification);
    }

    public List<Notification> getNotificationsForUser(Long recipientId) {
        return notificationRepository.findByRecipientId(recipientId);
    }
}

