package project1.project1.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import project1.project1.DAO.AdminRepository;
import project1.project1.DAO.AppointmentRepository;
import project1.project1.DAO.DoctorRepository;
import project1.project1.DAO.PatientRepository;
import project1.project1.model.Admin;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Admin addAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public Admin loginAdmin(String email, String password) {
        return adminRepository.findByEmailAndPassword(email, password);
    }

    public List<Object> manageUsers() {
        List<Object> users = new ArrayList<>();
        users.addAll(patientRepository.findAll());
        users.addAll(doctorRepository.findAll());
        return users;
    }

    public Map<String, Long> getSystemStats() {
        Map<String, Long> stats = new HashMap<>();
        stats.put("totalPatients", patientRepository.count());
        stats.put("totalDoctors", doctorRepository.count());
        stats.put("totalAppointments", appointmentRepository.count());
        return stats;
    }

	public Admin getAdminById(Long id) {
		// TODO Auto-generated method stub
		return adminRepository.findById(id).orElse(null);
	}
}
