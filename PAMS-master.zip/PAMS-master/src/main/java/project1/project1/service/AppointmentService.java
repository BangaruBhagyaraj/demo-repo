package project1.project1.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import project1.project1.DAO.AppointmentRepository;
import project1.project1.DAO.DoctorRepository;
import project1.project1.DAO.PatientRepository;
import project1.project1.model.Appointment;
import project1.project1.model.Doctor;
import project1.project1.model.Patient;

@Service
public class AppointmentService {
	
	@Autowired
	private PatientRepository patientRepository;
	
	@Autowired
	private DoctorRepository doctorRepository;	

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private NotificationService notificationService;

//    public Appointment bookAppointment(Appointment appointment) {
//        appointment.setStatus(Appointment.Status.BOOKED);
//        Appointment saved = appointmentRepository.save(appointment);
//        notificationService.sendConfirmationNotification(saved.getPatient().getPatientId(), "Appointment booked successfully.");
//        return saved;
//    }

    @Transactional
    public Appointment bookAppointment(Long patientId, Long doctorId, LocalDate date, LocalTime timeSlot) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(date);
        appointment.setTimeSlot(timeSlot);
        appointment.setStatus(Appointment.Status.BOOKED);

        return appointmentRepository.save(appointment);
    }


    
    public void cancelAppointment(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        if (appointment != null) {
            appointment.setStatus(Appointment.Status.CANCELED);
            appointmentRepository.save(appointment);
            notificationService.sendConfirmationNotification(appointment.getPatient().getPatientId(), "Appointment canceled.");
        }
    }

    public List<Appointment> viewAppointmentsByPatient(Long patientId) {
        return appointmentRepository.findByPatient_PatientId(patientId);
    }

    public List<Appointment> viewAppointmentsByDoctor(Long doctorId) {
        return appointmentRepository.findByDoctor_DoctorId(doctorId);
    }
}
