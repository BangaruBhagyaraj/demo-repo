package project1.project1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import project1.project1.DAO.AppointmentRepository;
import project1.project1.DAO.PatientRepository;
import project1.project1.model.Appointment;
import project1.project1.model.Patient;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Patient registerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public Patient loginPatient(String email, String password) {
        return patientRepository.findByEmailAndPassword(email, password);
    }

    public Patient updatePatientProfile(Patient updatedPatient) {
        return patientRepository.save(updatedPatient);
    }

    public List<Appointment> viewAppointmentHistory(Long patientId) {
        return appointmentRepository.findByPatient_PatientId(patientId);
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }
}


