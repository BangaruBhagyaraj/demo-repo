package project1.project1.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import project1.project1.DAO.AppointmentRepository;
import project1.project1.DAO.DoctorRepository;
import project1.project1.DAO.DoctorAvailabilityRepository;
import project1.project1.model.Appointment;
import project1.project1.model.Doctor;
import project1.project1.model.DoctorAvailability;

@Service
public class DoctorAvailabilityService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorAvailabilityRepository availabilityRepo;

    public void updateAvailability(Long doctorId, LocalDate date, LocalTime start, LocalTime end) {
        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow();
        DoctorAvailability availability = availabilityRepo
            .findByDoctor_DoctorIdAndDate(doctorId, date)
            .orElse(new DoctorAvailability());

        availability.setDoctor(doctor);
        availability.setDate(date);
        availability.setStartTime(start);
        availability.setEndTime(end);

        availabilityRepo.save(availability);
    }

    public List<LocalTime> getAvailableSlots(Long doctorId, LocalDate date) {
        DoctorAvailability availability = availabilityRepo
            .findByDoctor_DoctorIdAndDate(doctorId, date)
            .orElseThrow(() -> new RuntimeException("No availability set"));

        LocalTime start = availability.getStartTime();
        LocalTime end = availability.getEndTime();

        LocalTime lunchStart = LocalTime.of(13, 0);
        LocalTime lunchEnd = LocalTime.of(15, 0);

        List<Appointment> booked = appointmentRepository.findByDoctor_DoctorIdAndAppointmentDate(doctorId, date);
        Set<LocalTime> bookedSlots = booked.stream().map(Appointment::getTimeSlot).collect(Collectors.toSet());

        List<LocalTime> slots = new ArrayList<>();
        while (start.isBefore(end)) {
            boolean isLunchTime = !start.isBefore(lunchStart) && start.isBefore(lunchEnd);
            if (!bookedSlots.contains(start) && !isLunchTime) {
                slots.add(start);
            }
            start = start.plusMinutes(30);
        }
        return slots;
    }
}
