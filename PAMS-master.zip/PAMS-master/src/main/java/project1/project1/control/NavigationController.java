package project1.project1.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import project1.project1.model.Admin;
import project1.project1.model.Doctor;
import project1.project1.model.Patient;
import project1.project1.service.AdminService;
import project1.project1.service.DoctorService;
import project1.project1.service.PatientService;

@Controller
public class NavigationController {

    @Autowired
    private PatientService patientService;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private AdminService adminService;

    // Homepage
    @GetMapping("/")
    public String home() {
        return "index"; // index.html
    }

    // Book Now → new/existing user choice
    @GetMapping("/book-appointment")
    public String bookAppointment() {
        return "book_appointment"; // book_appointment.html
    }

    // New user → choose role
    @GetMapping("/register-choice")
    public String registerChoice() {
        return "middle_register"; // middle_register.html
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        Model model) {

        switch (role.toLowerCase()) {
            case "admin":
                Admin admin = adminService.loginAdmin(email, password);
                if (admin != null) {
                    return "redirect:/admin/dashboard?id=" + admin.getAdminId();
                }
                break;

            case "doctor":
            	
                Doctor doctor = doctorService.loginDoctor(email, password);
                if (doctor != null) {
                    return "redirect:/doctor/dashboard?id=" + doctor.getDoctorId();
                }
                break;

            case "patient":
                Patient patient = patientService.loginPatient(email, password);
                if (patient != null) {
                    return "redirect:/patient/dashboard?id=" + patient.getPatientId();
                }
                break;
        }

        model.addAttribute("error", "Invalid credentials or role mismatch");
        return "login";
    }
    
    
//    // Patient Registration
//    @GetMapping("/patient/register")
//    public String patientRegisterForm() {
//        return "patient_register"; // patient_register.html
//    }
//
//    @PostMapping("/patient/register")
//    public String registerPatient(Patient patient) {
//        patientService.registerPatient(patient);
//        return "redirect:/login";
//    }
//
//    // Doctor Registration
//    @GetMapping("/doctor/register")
//    public String doctorRegisterForm() {
//        return "Doctor_register"; // doctor_register.html
//    }
//
//    @PostMapping("/doctor/register")
//    public String registerDoctor(Doctor doctor) {
//        doctorService.addDoctor(doctor);
//        return "redirect:/login";
//    }
//
//    // Admin Registration
//    @GetMapping("/admin/register")
//    public String adminRegisterForm() {
//        return "admin_register"; // admin_register.html
//    }
//
//    @PostMapping("/admin/register")
//    public String registerAdmin(Admin admin) {
//        adminService.addAdmin(admin);
//        return "redirect:/login";
//    }

    
//    // Login Page
//    @GetMapping("/login")
//    public String loginPage() {
//        return "login"; // login.html
//    }
}
