package project1.project1.control;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import project1.project1.model.Appointment;
import project1.project1.model.Doctor;
import project1.project1.service.AppointmentService;
import project1.project1.service.DoctorAvailabilityService;
import project1.project1.service.DoctorService;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private DoctorAvailabilityService doctorAvailabilityService;

    // Doctor Registration
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("doctor", new Doctor());
        return "Doctor_register";
    }

    @PostMapping("/register")
    public String registerDoctor(@ModelAttribute Doctor doctor) {
        doctorService.addDoctor(doctor);
        return "SucessfullPage";
    }

    // Doctor Dashboard
    @GetMapping("/dashboard")
    public String dashboard(@RequestParam Long id, Model model) {
        Doctor doctor = doctorService.getDoctorById(id);
        List<Appointment> appointments = doctorService.viewDoctorSchedule(id);
        model.addAttribute("doctor", doctor);
        model.addAttribute("appointments", appointments);
        return "doctor-dashboard";
    }


    // Show Availability Update Form
    @GetMapping("/updateAvailability")
    public String showAvailabilityForm(@RequestParam Long id, Model model) {
        model.addAttribute("doctorId", id);
        return "doctor-update-availability";
    }

    // Handle Availability Submission
    @PostMapping("/updateAvailability")
    public String updateAvailability(@RequestParam Long doctorId,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime endTime,
                                     RedirectAttributes redirectAttributes) {
        doctorAvailabilityService.updateAvailability(doctorId, date, startTime, endTime);
        redirectAttributes.addFlashAttribute("message", "Availability updated successfully!");
        return "redirect:/doctor/dashboard?id=" + doctorId;
    }
    
    
}
