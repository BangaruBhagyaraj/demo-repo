package project1.project1.control;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import project1.project1.model.Appointment;
import project1.project1.service.AppointmentService;
import project1.project1.service.DoctorAvailabilityService;
import project1.project1.service.DoctorService;
import project1.project1.service.PatientService;

@Controller
@RequestMapping("/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private PatientService patientService;
    
    @Autowired
    private DoctorAvailabilityService doctorAvailabilityService;

    @GetMapping("/book")
    public String showBookingForm(@RequestParam Long patientId, Model model) {
        model.addAttribute("appointment", new Appointment());
        model.addAttribute("doctors", doctorService.getAllDoctors());
        model.addAttribute("patientId", patientId);
        model.addAttribute("availableSlots", new ArrayList<>()); // initially empty
        return "appointment-book";
    }
    
    @GetMapping("/slots")
    @ResponseBody
    public List<String> getAvailableSlots(@RequestParam Long doctorId,
                                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<LocalTime> slots = doctorAvailabilityService.getAvailableSlots(doctorId, date);
        return slots.stream().map(LocalTime::toString).toList();
    }

//    @PostMapping("/book")
//    public String bookAppointment(@ModelAttribute Appointment appointment, RedirectAttributes redirectAttributes, Model model) {
//        appointment.setStatus(Appointment.Status.BOOKED);
//        Appointment saved = appointmentService.bookAppointment(appointment);
//
//        model.addAttribute("patientId", saved.getPatient().getPatientId());
//        model.addAttribute("doctorName", saved.getDoctor().getName());
//        model.addAttribute("timeSlot", saved.getTimeSlot());
//        model.addAttribute("appointmentDate", saved.getAppointmentDate());
//
//        return "appointment-confirmation";
//    }
    
    
    
    @PostMapping("/book")
    public String bookAppointment(@RequestParam Long patientId,
                                   @RequestParam Long doctorId,
                                   @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate appointmentDate,
                                   @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime timeSlot,
                                   Model model) {

        Appointment saved = appointmentService.bookAppointment(patientId, doctorId, appointmentDate, timeSlot);

        model.addAttribute("patientId", saved.getPatient().getPatientId());
        model.addAttribute("doctorName", saved.getDoctor().getName());
        model.addAttribute("timeSlot", saved.getTimeSlot());
        model.addAttribute("appointmentDate", saved.getAppointmentDate());

        return "appointment-confirmation";
    }



    @PostMapping("/cancel")
    public String cancelAppointment(@RequestParam Long appointmentId, @RequestParam Long patientId) {
        appointmentService.cancelAppointment(appointmentId);
        return "redirect:/patient/dashboard?id=" + patientId;
    }
}

