package project1.project1.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import project1.project1.model.Appointment;
import project1.project1.model.Patient;
import project1.project1.service.AppointmentService;
import project1.project1.service.PatientService;

@Controller
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("patient", new Patient());
        return "patient_register";
    }

    @PostMapping("/register")
    public String registerPatient(@ModelAttribute Patient patient) {
        patientService.registerPatient(patient);
        return "SucessfullPage";
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam Long id, Model model,
                            @ModelAttribute("message") String message) {
        Patient patient = patientService.getPatientById(id);
        List<Appointment> appointments = appointmentService.viewAppointmentsByPatient(id);
        model.addAttribute("patient", patient);
        model.addAttribute("appointments", appointments);
        model.addAttribute("message", message); // ✅ Flash message support
        return "patient-dashboard";
    }



    @GetMapping("/update")
    public String showUpdateForm(@RequestParam Long id, Model model) {
        model.addAttribute("patient", patientService.getPatientById(id));
        return "patient-update";
    }

    @PostMapping("/update")
    public String updateProfile(@ModelAttribute Patient patient) {
        patientService.updatePatientProfile(patient);
        return "redirect:/patient/dashboard?id=" + patient.getPatientId();
    }
}
