package project1.project1.control;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import project1.project1.model.Admin;
import project1.project1.service.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("admin", new Admin());
        return "admin-register"; // Matches admin_register.html
    }

    @PostMapping("/register")
    public String registerAdmin(@ModelAttribute Admin admin) {
        adminService.addAdmin(admin);
        return "SucessfullPage";
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam Long id, Model model) {
        Admin admin = adminService.getAdminById(id);
        Map<String, Long> stats = adminService.getSystemStats();
        model.addAttribute("admin", admin);
        model.addAttribute("stats", stats);
        return "admin-dashboard";
    }

    @GetMapping("/manageUsers")
    public String manageUsers(Model model) {
        model.addAttribute("users", adminService.manageUsers());
        return "admin-manage-users";
    }
}

